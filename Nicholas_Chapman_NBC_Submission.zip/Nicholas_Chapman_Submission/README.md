Running the program:

To run the program simply run:

	python main.py

In order to configure the program you can play with the three parameters
found at the top of main.py. They are identified by their ALL_CAPS_STYLE. 